echo "Enter the file name: "
read -r file_name

# Check if the file is a ELF core dump file
if ! file "$file_name" | grep -q "ELF core dump"; then
  echo "The file is not a ELF core dump file. The file is compressed, please extract the file first and then try again. Compressed file can't be analyzed."
  exit 1
fi

input_string=$(strings "$file_name" | grep "/yugabyte/yb-software/yugabyte-" | head -1)
if [ -z "$input_string" ]; then
  input_string=$(strings "$file_name" | grep "yugabyte_version" | head -1 | awk '{print $2, $4}')
fi

modified_string=$(echo "$input_string" | awk -F "/" '{if ($3 == "yugabyte" && $4 == "yb-software") print $5}' | sed 's/centos/linux/' | sed 's/$/.tar.gz/')

echo "$modified_string"

