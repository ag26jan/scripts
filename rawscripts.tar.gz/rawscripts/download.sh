echo "Enter the file name: "
read -r file_name
file_output=$(file "$file_name")
if echo "$file_output" | grep "core file" > /dev/null; then
  echo "Great! The file is a valid core dump, proceeding with analysis."
else
  echo "The file is NOT an ELF core dump, please provide a valid core dump file. Make sure the file IS NOT compressed, if so please extract it and then try again!"
  exit 1
fi

input_string=$(strings "$file_name" | grep "/yugabyte/yb-software/yugabyte-" | head -1) || input_string=""
if [ -z "$input_string" ]; then
  input_string=$(strings "$file_name" | grep "yugabyte_version" | head -1 | awk '{print $2, $4}')
fi

modified_string=$(echo "$input_string" | awk -F "/" '{for (i=1; i<=NF; i++) if ($i == "yugabyte" && $(i+1) == "yb-software") print $(i+2)}' | sed 's/centos/linux/' | sed 's/$/.tar.gz/')

version=$(echo "$modified_string" | awk -F "-" '{print $2}')
output_string="https://downloads.yugabyte.com/releases/"$version"/"$modified_string""
echo "The final URL is: $output_string"


download_file="$modified_string"
if curl -L -# "$output_string" -o "$download_file"; then
  echo "Download of YB version file succeeded."
else
  echo "Download of YB version file failed."
fi

