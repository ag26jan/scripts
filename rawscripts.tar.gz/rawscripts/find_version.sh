echo "Enter the file name: "
read -r file_name
input_string=$(strings "$file_name" | grep "/yugabyte/yb-software/yugabyte-" | head -1)
if [ -z "$input_string" ]; then
  input_string=$(strings "$file_name" | grep "yugabyte_version" | head -1 | awk '{print $2, $4}')
fi

modified_string=$(echo "$input_string" | awk -F "/" '{if ($3 == "yugabyte" && $4 == "yb-software") print $5}' | sed 's/centos/linux/' | sed 's/$/.tar.gz/')

echo "$modified_string"
