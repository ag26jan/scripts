#This script is to take a text file containing the core file path and then search for the corresponding required YB binary version 

echo "Enter the file name: "
read -r file_name

counter=0
while read -r line; do
  counter=$((counter + 1))
  input_string=$(echo "$line" | strings | grep "/yugabyte/yb-software/yugabyte-" | head -1)
  if [ -z "$input_string" ]; then
    input_string=$(echo "$line" | strings | grep "yugabyte_version" | head -1 | awk '{print $2, $4}')
  fi

  modified_string=$(echo "$input_string" | awk -F "/" '{if ($3 == "yugabyte" && $4 == "yb-software") print $5}' | sed 's/centos/linux/' | sed 's/$/.tar.gz/')

  if [ -z "$modified_string" ]; then
    echo "Line $counter: No output"
  else
    echo "Line $counter: $modified_string"
  fi
done < "$file_name"

