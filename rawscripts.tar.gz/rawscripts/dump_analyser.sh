echo "Enter the file name: "
read -r file_name
file_output=$(file "$file_name")
if echo "$file_output" | grep "core file" > /dev/null; then
  echo "Great! The file is a valid core dump, proceeding with analysis."
else
  echo "The file is NOT an ELF core dump, please provide a valid core dump file. Make sure the file IS NOT compressed, if so please extract it and then try again!"
  exit 1
fi

input_string=$(strings "$file_name" | grep "/yugabyte/yb-software/yugabyte-" | head -1) || input_string=""
if [ -z "$input_string" ]; then
  input_string=$(strings "$file_name" | grep "yugabyte_version" | head -1 | awk '{print $2, $4}')
fi

modified_string=$(echo "$input_string" | awk -F "/" '{for (i=1; i<=NF; i++) if ($i == "yugabyte" && $(i+1) == "yb-software") print $(i+2)}' | sed 's/centos/linux/' | sed 's/$/.tar.gz/')

version=$(echo "$modified_string" | awk -F "-" '{print $2}')
output_string="https://downloads.yugabyte.com/releases/"$version"/"$modified_string""
echo "The final URL is: $output_string"



download_file="$modified_string"
target_dir="/cases/home/yugabyte/yb-software/"

if
curl -L -# "$output_string" -o "$target_dir/$modified_string"; then
  echo "Download of YB version file succeeded."
else
  echo "Download of YB version file failed."
  exit 1
fi


tar_file="$target_dir/$modified_string"

echo "Extracting $tar_file in $target_dir"
tar -xzf "$tar_file" -C "$target_dir" --strip-components=1 &>/dev/null


post_install="$target_dir/yugabyte-$version/bin/post_install.sh"

if [ -f "$post_install" ]; then
echo "Executing $post_install"
sh "$post_install"
else
  echo "$post_install not found, exiting."
  exit 1
fi

